document.addEventListener('DOMContentLoaded', () => {

  /* ============================================
     MOBILE NAV
     ============================================ */
  const navToggle = document.getElementById('nav-toggle');
  const mainNav = document.getElementById('main-nav');

  navToggle.addEventListener('click', () => {
    const isOpen = mainNav.classList.toggle('is-open');
    navToggle.classList.toggle('is-active', isOpen);
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });

  mainNav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      mainNav.classList.remove('is-open');
      navToggle.classList.remove('is-active');
      navToggle.setAttribute('aria-expanded', 'false');
    });
  });

  /* ============================================
     SCROLL REVEAL
     ============================================ */
  const revealEls = document.querySelectorAll('.reveal');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  revealEls.forEach(el => revealObserver.observe(el));

  /* ============================================
     COUNT-UP STATS
     ============================================ */
  const counters = document.querySelectorAll('.num');
  const countObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseInt(el.dataset.count, 10);
      const duration = 1200;
      const start = performance.now();

      function step(now) {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.round(eased * target);
        if (progress < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
      countObserver.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(el => countObserver.observe(el));

  /* ============================================
     TERMINAL TYPING EFFECT
     ============================================ */
  const lines = [
    'whoami',
    '> Raka Pramudya — Full-Stack Developer',
    'status --check',
    '> Tersedia untuk proyek baru ✓'
  ];
  const lineEls = [
    document.getElementById('tline-1'),
    document.getElementById('tline-2'),
    document.getElementById('tline-3'),
    document.getElementById('tline-4')
  ];
  const cursor = document.getElementById('cursor');

  function typeLine(index) {
    if (index >= lines.length) return;
    const el = lineEls[index];
    if (!el) return;
    const text = lines[index];
    let charIndex = 0;

    // Lines starting with "> " are output lines, shown without the "$ " prompt style delay char-by-char too
    function typeChar() {
      el.textContent = text.slice(0, charIndex + 1);
      charIndex++;
      if (charIndex < text.length) {
        setTimeout(typeChar, 28);
      } else {
        setTimeout(() => typeLine(index + 1), 400);
      }
    }
    typeChar();
  }

  const heroObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        typeLine(0);
        heroObserver.disconnect();
      }
    });
  }, { threshold: 0.3 });
  const terminalEl = document.querySelector('.terminal');
  if (terminalEl) heroObserver.observe(terminalEl);

  /* ============================================
     PROJECT FILTER
     ============================================ */
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  function applyFilter(filter) {
    projectCards.forEach(card => {
      const match = filter === 'all' || card.dataset.cat === filter;
      card.classList.toggle('is-shown', match);
    });
  }
  applyFilter('all');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      applyFilter(btn.dataset.filter);
    });
  });

  /* ============================================
     HEADER SHADOW ON SCROLL + TO-TOP BUTTON
     ============================================ */
  const header = document.getElementById('site-header');
  const toTopBtn = document.getElementById('to-top');

  window.addEventListener('scroll', () => {
    const scrolled = window.scrollY > 40;
    header.style.boxShadow = scrolled ? '0 6px 20px rgba(16,21,28,0.06)' : 'none';
    toTopBtn.classList.toggle('is-visible', window.scrollY > 500);
  });

  toTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ============================================
     CONTACT FORM VALIDATION (no alert, inline messages)
     ============================================ */
  const form = document.getElementById('contact-form');
  const statusEl = document.getElementById('form-status');

  const messages = {
    'cf-name': 'Nama minimal 2 karakter.',
    'cf-email': 'Masukkan alamat email yang valid.',
    'cf-budget': 'Pilih perkiraan ruang lingkup proyek.',
    'cf-message': 'Ceritakan sedikit lebih detail (min. 10 karakter).'
  };

  function showError(id, message) {
    const el = form.querySelector(`.field-error[data-for="${id}"]`);
    if (el) el.textContent = message || '';
  }

  function validateField(field) {
    const valid = field.checkValidity();
    showError(field.id, valid ? '' : (messages[field.id] || 'Periksa kembali kolom ini.'));
    return valid;
  }

  form.querySelectorAll('input, select, textarea').forEach(field => {
    field.addEventListener('blur', () => validateField(field));
    field.addEventListener('input', () => {
      if (field.value) showError(field.id, '');
    });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const fields = form.querySelectorAll('input, select, textarea');
    let allValid = true;
    fields.forEach(field => {
      if (!validateField(field)) allValid = false;
    });

    if (!allValid) {
      statusEl.textContent = 'Ada beberapa kolom yang perlu diperbaiki di atas.';
      statusEl.style.color = '#FF5A1F';
      return;
    }

    const name = form.querySelector('#cf-name').value;
    statusEl.style.color = '#2B5797';
    statusEl.textContent = `Terima kasih, ${name}. Pesan Anda sudah tercatat — saya akan segera membalas.`;
    form.reset();
  });

  /* ============================================
     FOOTER YEAR
     ============================================ */
  const year = new Date().getFullYear();
  const footerYear = document.getElementById('footer-year');
  const tbYear = document.getElementById('tb-year');
  if (footerYear) footerYear.textContent = year;
  if (tbYear) tbYear.textContent = year;

});
